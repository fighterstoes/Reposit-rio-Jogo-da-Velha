package iu;

public class Principal {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		if(args.length==0)
		 IUJogoDaVelha.inicia("");
		 else  IUJogoDaVelha.inicia(args[0]);
	}

}
