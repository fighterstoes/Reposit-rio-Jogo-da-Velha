package iu;

import java.util.Scanner;

import javax.swing.JOptionPane;

public class IUJogoDaVelha {

	private static char iu;
	private static char op;

	public static void inicia(String args) {
		args.toLowerCase();
		switch (args.length()){
		case 0: case 1:
			if((args.length()==0)||(args.equals("t"))) {
				iu='t'; System.out.println("Modo Texto Ativado");
				selecionarOponente();
			}else if (args.equals("g")){
				iu='g';
				JOptionPane.showMessageDialog(null, "Tic Tac Toes");
				selecionarOponenteG();
			}else {
				System.err.println("argumento invalido");
				System.exit(0);
			}break;

		case 2: 
			iu= (((args.charAt(0)=='t')||(args.charAt(0)=='g'))?args.charAt(0):' ');
			op= (((args.charAt(1)=='p')||(args.charAt(1)=='c'))?args.charAt(1):' ');
			if((iu==' ')||(op==' ')){
				System.err.println("argumento invalido");
				System.exit(0);
			}else{
				if(iu=='t') System.out.println("Modo Texto Ativado");
				else JOptionPane.showMessageDialog(null, "Tic Tac Toes");
				if(op=='c') JOptionPane.showMessageDialog(null,"Boa Sorte contra nossa lógica (^.~) ");
				else JOptionPane.showMessageDialog(null, "Bom jogo para vocês (^.^)v ");
			}break;
		default: System.err.println("argumento invalido");
				 System.exit(0);
				 break;
		}
	}

	private static void selecionarOponente() {
		// TODO Auto-generated method stub
		System.out.println("Quem é seu oponente? 1 = Computador 2 = Jogador2");
		Scanner sc = new Scanner(System.in);
		int op = sc.nextInt();
		switch (op){
		case 1: System.out.println("Boa Sorte contra nossa lógica (^.~) "); op ='c'; break;
		case 2: System.out.println("Bom jogo para vocês (^.^)v "); op='p'; break;
		default: System.err.println("Entre uma opção de adversario válida");break;
		}
	}

	private static void selecionarOponenteG() {
		// TODO Auto-generated method stub
		int op = JOptionPane.showConfirmDialog(null, "Outro Jogador - Yes \n Máquina - No", "Quem é seu oponente?",1);
		switch (op){
		case 1: JOptionPane.showMessageDialog(null,"Boa Sorte contra nossa lógica (^.~) "); op ='c'; break;
		case 0: JOptionPane.showMessageDialog(null,"Bom jogo para vocês (^.^)v "); op='p'; break;
		case 2: System.exit(0); break;
		default: JOptionPane.showMessageDialog(null,"Clique em uma opção válida");break;
		}
	}

}
