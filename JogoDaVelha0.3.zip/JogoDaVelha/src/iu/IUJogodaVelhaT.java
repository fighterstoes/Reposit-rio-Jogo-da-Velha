package iu;

import java.util.Scanner;
import negocio.RegrasDoJogoDaVelha;

public class IUJogodaVelhaT {
	private static char[][] tabuleiro = new char[3][3];
	private static boolean velhou = false, ganhou=false, partida=true;
	private static char vez;

	public static void iniciaJogoTP(){
		while(partida){
			vez='o';
			for(int i=0;i<3;i++){
				for(int j=0;j<3;j++){tabuleiro[i][j]=' ';}}
			while((!velhou)&&(!ganhou)){
				escreverTabuleiro(tabuleiro);
				tabuleiro = leituraJogadaT(tabuleiro);
				ganhou = RegrasDoJogoDaVelha.ganhou(tabuleiro);
				if (ganhou)System.out.printf("Parabéns! "+(vez=='o'?'X':'O')+" ganhou!\n");
				
				velhou = RegrasDoJogoDaVelha.velhou(tabuleiro);
				if (velhou)System.out.printf("Ops! Velhou...");
			}
			System.out.printf("Deseja jogar outra partida? 0 = não\n");
			Scanner sc = new Scanner(System.in);
			if(sc.nextInt()==0){ partida=false; System.exit(0);} 
		}
	}

	static void escreverTabuleiro(char[][] t){
		System.out.println("   0 | 1 | 2 ");
		for(int i=0;i<3;i++){
			System.out.printf(i+" ");
			for(int j=0;j<3;j++){
				if(t[i][j]==' ') System.out.printf("___");
				else System.out.printf("_"+t[i][j]+"_");
				if(j!=2)System.out.printf("|");
				else System.out.println();
			}}
		System.out.println("     |   |   ");
		System.out.println("");
	}

	static char[][] leituraJogadaT(char[][] t){
		System.out.println("Jogador "+vez+"\n");
		Scanner sc = new Scanner(System.in);
		System.out.printf(" l:");
		int i = sc.nextInt();
		System.out.printf(" c:");
		int j = sc.nextInt();
		if(RegrasDoJogoDaVelha.jogadaValida(t, i,j)){
			t[i][j]=vez;
			if(vez=='o') vez='x';
			else vez='o';
		}else System.out.println("Jogada Invalida");

		return t;
	}

}
