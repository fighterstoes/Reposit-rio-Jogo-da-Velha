package iu;

import javax.swing.JOptionPane;

public class IUJogoDaVelha {

	private static char iu;

	public static void inicia(String iuSelecionada) {
		if((iuSelecionada.length()==0)||(iuSelecionada.equals("t"))) {
			iu='t'; System.out.println("Modo Texto Ativado");
			}else if (iuSelecionada.equals("g")){
				iu='g';
				JOptionPane.showMessageDialog(null, "Tic Tac Toes");
			}
			else {
					System.err.println("argumento invalido");
					System.exit(0);}
				}
			
}
