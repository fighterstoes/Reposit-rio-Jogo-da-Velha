package iu;

public class Principal {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		switch (args.length){
		case 0: IUJogoDaVelha.inicia(""); break;
		case 1: IUJogoDaVelha.inicia(args[0]);break;
		default:  System.err.println("uso: java JogoDaVelha "
				+ "[interface] g gráfica, t textual, sem args interface textual é default");
		System.exit(0);
		break;
		}
	}

}
