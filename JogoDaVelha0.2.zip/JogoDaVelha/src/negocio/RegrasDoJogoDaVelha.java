package negocio;

public class RegrasDoJogoDaVelha {
	
	public static boolean jogadaValida(char[][] t, int i, int j){
		if (t[i][j]==' ')	return true;
		else return false;
	}
	
	public static boolean ganhou(char[][] t){
		boolean g=true;
    	for(int i=0;i<3;i++){
        	for(int j=1;j<3;j++){
        		if((t[i][j-1]!=t[i][j])||(t[j-1][i]!=t[j][i])){System.out.println("hey"); g = false;} 
        	}
        }
    	for(int i=1;i<3;i++)
       		if((t[i-1][i-1]!=t[i][i])||(t[i-1][3-i]!=t[i][2-i])) {System.out.println("hey"); g = false;}
    	
    	return g;
	}
	
	public static boolean velhou(char[][] t){
		boolean v=true;
		for(int i=0;i<3;i++){
        	for(int j=1;j<3;j++){
        		if(t[i][j]==' ') v = false;
        	}}
		return v;
	}

}
