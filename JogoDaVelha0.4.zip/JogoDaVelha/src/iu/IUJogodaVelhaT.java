package iu;

import java.util.Scanner;
import negocio.RegrasDoJogoDaVelha;

public class IUJogodaVelhaT {
	private static char[][] tabuleiro = new char[3][3];
	private static boolean velhou, ganhou, partida;
	private static char vez;

	public static void iniciaJogoTP(){
		velhou=false; ganhou=false; partida=true;
		while(partida){
			vez='o';
			limpaTabuleiro();
			while((!velhou)&&(!ganhou)){
				escreverTabuleiro();
				lerJogadaT();
				if(velhou)break; 
				verificarStatus();
			}
			System.out.println("Deseja jogar outra partida? 0 = não\n");
			Scanner sc = new Scanner(System.in);
			if(sc.nextInt()==0)System.exit(0); 
		}
	}

	static void escreverTabuleiro(){
		System.out.println("    0 . 1 . 2 ");
		for(int i=0;i<3;i++){
			System.out.printf(i+". ");
			for(int j=0;j<3;j++){
				if(i!=2)
					if((tabuleiro[i][j]==' ')) System.out.printf("___");
					else System.out.printf("_"+tabuleiro[i][j]+"_");
				else
					if((tabuleiro[i][j]==' ')) System.out.printf("   ");
					else System.out.printf(" "+tabuleiro[i][j]+" ");
				if(j!=2)System.out.printf("|");
				else System.out.println();

			}}
		System.out.println();
	}

	static void lerJogadaT(){
		System.out.println("Jogador "+vez);
		Scanner sc = new Scanner(System.in);
		boolean valeu=false;
		int i,j;
		do{
			System.out.printf(" linha:");
			i = sc.nextInt();
			System.out.printf(" coluna:");
			j = sc.nextInt();
			if(!desejaAbortar(i,j)){
				valeu = RegrasDoJogoDaVelha.jogadaValida(tabuleiro, i,j);
				if(!valeu) System.out.println("Posição Ocupada");
				else{tabuleiro[i][j]=vez;
				trocaVez();}
			}else break;

		}while(!valeu);
	}

	private static void trocaVez() {
		if(vez=='o') vez='x';
		else vez='o';
	}

	private static void limpaTabuleiro(){
		for(int k=0;k<3;k++){
			for(int j=0;j<3;j++){tabuleiro[k][j]=' ';}}
	}

	private static void verificarStatus(){
		ganhou = RegrasDoJogoDaVelha.ganhou(tabuleiro);
		if (ganhou){System.out.println("\t"+(vez=='o'?'X':'O')+" ganhou!\n");}
		velhou = RegrasDoJogoDaVelha.velhou(tabuleiro);
		if (velhou){System.out.println("Ops! Velhou...\n");}
		if(velhou||ganhou) escreverTabuleiro();
	}

	static boolean desejaAbortar(int i, int j){
		Scanner sc = new Scanner(System.in);
		if((i>2)||(i<0)||(j>2)||(j<0)){
			System.out.println("Digitou uma posição invalida\nDeseja Abortar a partida? 0 = Sim");
			if(0==sc.nextInt()){velhou=true; return true;}
		}return false;
	}
}
